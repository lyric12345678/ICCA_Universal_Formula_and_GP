clear
clc
%% Figure Plotting
load x_True
load u_True
u_True = u_save;
x_True = x;
load x_Uni_GP
load u_Uni_GP
u_Uni_GP = u_save;
x_Uni_GP = x;
load x_Uni_Mismatch
load u_Uni_Mismatch
u_Uni_Mismatch = u_save;
x_Uni_Mismatch = x;
t_span=[0:0.1:100];                                                        % Running time and interval

[Init_Par]=Initial_Parameter();

%% Ode4 plot
figure(1)
subplot(1,3,1)
plot(t_span,x_True(:,2),'r-','linewidth',2)
hold on
plot(t_span,x_True(:,1),'k-','linewidth',2)
plot(t_span,x_Uni_Mismatch(:,1),'b.-','linewidth',2)
plot(t_span,x_Uni_GP(:,1),'m--','linewidth',2)
set(gca,'FontSize',18)
set(gcf,'Position',[200,200,1800,500], 'color','w')
xlabel('x1')
ylabel('x2')
legend('$v_{l}$: Leading vehicle','$v_{f}$: True Dynamics','$v_{f}$: Mismatch Dynamics','$v_{f}$: GP-Learning Dynamics','Interpreter','latex')
grid on

%% Compute the CBF
hTrue_safe=x_True(:,3)-Init_Par.tau_d*x_True(:,1);
hMismatch_safe=x_Uni_Mismatch(:,3)-Init_Par.tau_d*x_Uni_Mismatch(:,1);
hGP_safe=x_Uni_GP(:,3)-Init_Par.tau_d*x_Uni_GP(:,1);
subplot(1,3,2)
plot(t_span,hTrue_safe,'k-','linewidth',2)
hold on
plot(t_span,hMismatch_safe,'b.-','linewidth',2)
plot(t_span,hGP_safe,'m--','linewidth',2)
plot(t_span,zeros(1,length(t_span)),'g--','linewidth',2)
set(gca,'FontSize',18)
set(gcf,'Position',[200,200,1800,500], 'color','w')
xlabel('T')
ylabel('$h_{S}$','Interpreter','latex')
legend('$h_{S}$: True Dynamics','$h_{S}$: Mismatch Dynamics','$h_{S}$: GP-Learning Dynamics','Interpreter','latex')
grid on


subplot(1,3,3)
for i_u=1:size(x,1)-1
    u_Trueorigin(i_u)=(u_True(1+(i_u-1)*4))/Init_Par.M/Init_Par.a_g;
    u_Uni_GPorigin(i_u)=(u_Uni_GP(1+(i_u-1)*4))/Init_Par.M/Init_Par.a_g;
    u_Uni_Mismatchorigin(i_u)=(u_Uni_Mismatch(1+(i_u-1)*4))/Init_Par.M/Init_Par.a_g;
end
plot(t_span(2:end),u_Trueorigin,'k-','linewidth',2)
hold on 
plot(t_span(2:end),u_Uni_Mismatchorigin,'b.-','linewidth',2)
plot(t_span(2:end),u_Uni_GPorigin,'m--','linewidth',2)
set(gca,'FontSize',18)
set(gcf,'Position',[200,200,1800,500], 'color','w')
xlabel('t')
ylabel('$u/Mg$','Interpreter','latex')
legend('$u/Mg$: True Dynamics','$u/Mg$: Mismatch Dynamics','$u/Mg$: GP-Learning Dynamics','Interpreter','latex')
grid on










