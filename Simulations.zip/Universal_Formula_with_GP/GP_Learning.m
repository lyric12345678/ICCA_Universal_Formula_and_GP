function [mu s3] = GP_Learning(Init_Par)
%% We use GP to learn model uncertainty
%Generate Training data
[x_learn,wx_learn]=Generate_Training_Data(Init_Par);
% Add noise to wx_learn
wx_learn=wx_learn + 0.1*randn(1,length(wx_learn));

%Use Training data to obtain mean function and covariance
x = x_learn.';                 % 20 training inputs
y = wx_learn.';  % 20 noisy training targets
xs = linspace(0, 100, Init_Par.N_samples)';                  % 61 test inputs
meanfunc = [];                    % empty: don't use a mean function
covfunc = @covSEiso;              % Squared Exponental covariance function
likfunc = @likGauss;              % Gaussian likelihood
hyp = struct('mean', [], 'cov', [0 0], 'lik', -1);
hyp2 = minimize(hyp, @gp, -100, @infGaussLik, meanfunc, covfunc, likfunc, x, y);
[mu s3] = gp(hyp2, @infGaussLik, meanfunc, covfunc, likfunc, x, y, xs);
f = [mu+3*sqrt(s3); flipdim(mu-3*sqrt(s3),1)];
fill([xs; flipdim(xs,1)], f, [7 7 7]/8)
hold on; plot(xs, mu,'r-'); plot(x, y, 'b+')
axis([0,100,-20,20])
end

