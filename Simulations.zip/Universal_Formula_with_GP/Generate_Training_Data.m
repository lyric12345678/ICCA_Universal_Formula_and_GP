% function [Input_Pair,wx_learn]=Generate_Training_Data(Init_Par)
% n_sampleX=20;
% n_sampleY=20;
% n_sampleZ=20;
% Total_InputSamples=n_sampleX*n_sampleY*n_sampleZ;
% x_learn=zeros(3,Total_InputSamples);
% s=1;
% for i=1:n_sampleX
%     for j=1:n_sampleY
%         for k=1:n_sampleZ
%             x_learn(:,s)=[8+20/Total_InputSamples*s,8+20/Total_InputSamples*s,20+140/Total_InputSamples*s];
%             s=s+1;
%         end
%     end
% end
% n_samplesU=40-1;
% u_learn=-0.6:1.2/n_samplesU:0.6;
%
% %Store the generated control input
% % %% Define the acceleration of the leading vehicle
% a_L=1;
%
%
% %% Dynamics of the system
% q=1;
% Total_OutputSamples=n_sampleX*n_sampleY*n_sampleZ*n_samplesU;
% xdot_meas=zeros(3,Total_OutputSamples);
% Input_Pair=zeros(4,Total_OutputSamples);
% for s=1:Total_InputSamples
%     for p=1:n_samplesU
%         Input_Pair(:,q)=[x_learn(:,s);u_learn(p)];
%         Init_Par.F_r=Init_Par.f_0+Init_Par.f_1*x_learn(1,s)+Init_Par.f_2*(x_learn(1,s))^2;% Rolling resistance (force)
%         xdot_meas(1,q)=-Init_Par.F_r/Init_Par.M+u_learn(p)/Init_Par.M;                           %Note that u is essentially the wheel force
%         xdot_meas(2,q)=a_L;
%         xdot_meas(3,q)=x_learn(2,s)-x_learn(1,s);
%         q=q+1;
%     end
% end
%
% %Inaccurate xdot (nominal)
% q=1;
% xdot_nominal=zeros(3,Total_OutputSamples);
% for s=1:Total_InputSamples
%     for p=1:n_samplesU
%         Init_Par.mis_F_r=Init_Par.mis_f_0+Init_Par.mis_f_1*x_learn(1,s)+Init_Par.mis_f_2*(x_learn(1,s))^2;% Rolling resistance (force)
%         xdot_nominal(1,q)=-Init_Par.mis_F_r/Init_Par.M+u_learn(p)/Init_Par.M;                           %Note that u is essentially the wheel force
%         xdot_nominal(2,q)=a_L;
%         xdot_nominal(3,q)=x_learn(2,s)-x_learn(1,s);
%         wx_learn(1,q)=xdot_meas(1,q)-xdot_nominal(1,q);
%         wx_learn(2,q)=xdot_meas(2,q)-xdot_nominal(2,q);
%         wx_learn(3,q)=xdot_meas(3,q)-xdot_nominal(3,q);
%         q=q+1;
%     end
% end
%
% end
%
%



function [x_learn,wx_learn]=Generate_Training_Data(Init_Par)
n_sampleX=Init_Par.N_samples;
x_learn=zeros(1,n_sampleX);
for i=1:n_sampleX
    x_learn(:,i)=[8+20/n_sampleX*i];
end

for i=1:n_sampleX
    Init_Par.F_r=Init_Par.f_0+Init_Par.f_1*x_learn(1,i)+Init_Par.f_2*(x_learn(1,i))^2;% Rolling resistance (force)
    Init_Par.mis_F_r=Init_Par.mis_f_0+Init_Par.mis_f_1*x_learn(1,i)+Init_Par.mis_f_2*(x_learn(1,i))^2;% Rolling resistance (force)
    wx_learn(1,i)=(Init_Par.mis_F_r-Init_Par.F_r)/Init_Par.M;
end
end








