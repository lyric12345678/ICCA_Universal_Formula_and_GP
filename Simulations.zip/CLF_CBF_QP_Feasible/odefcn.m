function dxdt = odefcn(t,x)
global u_save
dxdt = zeros(3,1);
% Note that [x(1) x(2) x(3)]==[v_f v_l D]
% time
t
[Init_Par]=Initial_Parameter();
Init_Par.F_r=Init_Par.f_0+Init_Par.f_1*x(1)+Init_Par.f_2*(x(1))^2;% Rolling resistance (force)
h_safe=x(3)-Init_Par.tau_d*x(1);
h_goal=(x(1)-Init_Par.v_d)^2;

%% Formulate and Solve the QPs
%  Use function quadprog
Lf_goal=-2*(x(1)-Init_Par.v_d)*(Init_Par.F_r)/Init_Par.M;
Lg_goal=2*(x(1)-Init_Par.v_d)/Init_Par.M;
Lf_hS = x(2)-x(1)+Init_Par.tau_d*Init_Par.F_r/Init_Par.M;
Lg_hS = -Init_Par.tau_d/Init_Par.M;
A=[Lg_goal,-1;-Lg_hS,0];
b=[-Lf_goal-Init_Par.c_convergence_rate*h_goal,Lf_hS+Init_Par.gamma*h_safe].';
H=2*[1/(Init_Par.M^2),0;0,Init_Par.p_sc];
F=-2*[Init_Par.F_r/(Init_Par.M^2),0].';
[u]=quadprog(H,F,A,b);
u_save=[u_save,u(1)];
if t<=8
    a_L = 0;
elseif t<=18
    a_L = 1.2;
elseif t<=30
    a_L = 0;
elseif t<=40
    a_L = 0.5;
elseif t<=50
    a_L = 0;
elseif t<=60
    a_L = -1;
else
    a_L = 0;
end

%% Dynamics of the system
dxdt(1)=-Init_Par.F_r/Init_Par.M+u(1)/Init_Par.M;                           %Note that u is essentially the wheel force
dxdt(2)=a_L;
dxdt(3)=x(2)-x(1);
end