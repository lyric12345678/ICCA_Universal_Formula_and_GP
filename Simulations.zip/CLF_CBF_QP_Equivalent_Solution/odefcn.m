function dxdt = odefcn(t,x)
global u_save
dxdt = zeros(3,1);
% Note that [x(1) x(2) x(3)]==[v_f v_l D]
% time
t
[Init_Par]=Initial_Parameter();
Init_Par.F_r=Init_Par.f_0+Init_Par.f_1*x(1)+Init_Par.f_2*(x(1))^2;% Rolling resistance (force)

%% Three different types of constraints
h_safe=x(3)-Init_Par.tau_d*x(1);
h_goal=(x(1)-Init_Par.v_d)^2;


%% Formulate the Universal Formula
Lf_goal=-2*(x(1)-Init_Par.v_d)*(Init_Par.F_r)/Init_Par.M;
Lg_goal=2*(x(1)-Init_Par.v_d)/Init_Par.M;
Lf_hS = x(2)-x(1)+Init_Par.tau_d*Init_Par.F_r/Init_Par.M;
Lg_hS = -Init_Par.tau_d/Init_Par.M;
b_x=Lg_goal*Init_Par.M;
d_x=Lg_hS*Init_Par.M;
a_x=Lf_goal+5*h_goal;
c_x=Lf_hS+0.5*h_safe;

kappa=0.2;
rho=0.1;
Sigma_x=sqrt(a_x^2+(b_x*b_x.'));
Gamma_x=sqrt(c_x^2+d_x*d_x.');
k_clf=-(a_x+kappa*Sigma_x)/(1/Init_Par.p_sc+b_x*b_x.')*b_x;
k_cbf=-(c_x-rho*Gamma_x)/(d_x*d_x.')*d_x;
w_x=(a_x+kappa*Sigma_x)*d_x*d_x.'-(c_x-rho*Gamma_x)*b_x*d_x.';
v_x=(a_x+kappa*Sigma_x)*d_x*b_x.'-(c_x-rho*Gamma_x)*(1/Init_Par.p_sc+b_x*b_x.');
R_x_bar=[b_x*b_x.'+1/Init_Par.p_sc,-b_x*d_x.';-b_x*d_x.',d_x*d_x.'];
lamda_bar=inv(R_x_bar)*[(a_x+kappa*Sigma_x);-(c_x-rho*Gamma_x)];
lamda_bar_1=lamda_bar(1);
lamda_bar_2=lamda_bar(2);


%% Domain of sets
if a_x+kappa*Sigma_x>=0 && v_x<0
   u=k_clf;
end

if c_x-rho*Gamma_x<=0 && w_x<0
   u=k_cbf;
end

if w_x>=0 && v_x>=0 
u=-lamda_bar_1*b_x+lamda_bar_2*d_x;
end

if a_x+kappa*Sigma_x<0 && c_x-rho*Gamma_x>0
    u=zeros(1,length(b_x));
end

u=u*Init_Par.M+Init_Par.F_r;
u_save=[u_save,u];



% a_L=0;
%Store the generated control input
% %% Define the acceleration of the leading vehicle
if t<=8
    a_L = 0;
elseif t<=18
    a_L = 1.2;
elseif t<=30
    a_L = 0;
elseif t<=40
    a_L = 0.5;
elseif t<=50
    a_L = 0;
elseif t<=60
    a_L = -1;
else
    a_L = 0;
end

%% Dynamics of the system
dxdt(1)=-Init_Par.F_r/Init_Par.M+u(1)/Init_Par.M;                           %Note that u is essentially the wheel force
dxdt(2)=a_L;
dxdt(3)=x(2)-x(1);
end